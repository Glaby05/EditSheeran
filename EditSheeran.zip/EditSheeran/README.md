# EditSheeran

CCT211 Project

Tkinter GUI app that's an Ed Sheeran photo card editor, which will let the user customize different aspects of Ed Sheeran, and save it into different save files as .json files and give the user the option to export as a picture. 

## FEATURES

- to be determined